<?php
session_start();
require_once("db.php");

$RideID = $_GET['RideID'];
$pass = RideshareData::getDBInstance()->passenger_details($_SESSION['email']);

$CPID = $pass[0];


if (RideshareData::getDBInstance()->participates($CPID, $RideID) > 0){
    echo '<script>alert("Already in the ride");</script>';
} else {
    if ($_SERVER['REQUEST_METHOD'] == "POST") {

        $msg = RideshareData::getDBInstance()->join_ride($CPID, $RideID, $_POST['type'], $_POST['seats']);
        echo '<script>alert("'.$msg.'");</script>';
    }

}

?>

    <!DOCTYPE html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    </head>
    <body>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <nav class="navbar navbar-default" role="navigation">
                    <div class="col-md-5">
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="home-passenger.php".php"><img src="assests/ride.jpg" style="width: 45%; padding: 0px;margin: 0px"></a>
                            </li>
                    </div>
                    <div class="col-md-5">
                        <ul class="nav navbar-nav">
                            <li><h1>Passenger Portal</h1></li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <ul class="nav navbar-nav">
                            <li><a href="logout.php"><img src="assests/shutdown.png" style="width: 30%"></a></li>
                        </ul>
                    </div>
                </nav>
            </div>

                <div class="jumbotron">
                    <h2><?php if (array_key_exists("email", $_SESSION)) {
                            echo "Hi, " . $_SESSION['email']. $CPID;} ?>! </h2>

                </div>

                <div>
                    <h3>Rideshare Info</h3>

                    <table class = "table table-striped table-bordered table-condensed" border="black">
                        <tr>
                            <th>Date</th>
                            <th>Time</th>
                            <th>Driver Name</th>
                            <th>Destination</th>
                            <th>PickUp</th>
                            <th>Price</th>
                            <th>Seats</th>
                            <th>Seats Left</th>
                        </tr>

                        <?php

                        $result = RideshareData::getDBInstance()->rides($RideID);

                        if ($result->num_rows > 0) {
                            // output data of each row
                            while($row = $result->fetch_assoc()) {
                                $maxseats = number_format($row['seats_left']);
                                echo "<tr><td>" . htmlentities($row['ride_date']) . "</td>";
                                echo "<td>" . htmlentities($row['ride_time']) . "</td>";
                                echo "<td>" . htmlentities($row['name']) . "</td>";
                                echo "<td>" . htmlentities($row['destination']) . "</td>";
                                echo "<td>" . htmlentities($row['address']) . "</td>";
                                echo "<td>" . htmlentities($row['price']) . "</td>";
                                echo "<td>" . htmlentities($row['seats']) . "</td>";
                                echo "<td>" . htmlentities($row['seats_left']) . "</td></tr>\n";
                            }
                        }
                        ?>
                    </table>
                </div>
                <div>
                    <form role = "form" action="ride-info-passanger.php?RideID=<?php echo $RideID; ?>" method="POST">
                        <h3> Payment type: </h3>
                        <select class = "form-control" name="type">
                            <option value="cash">Cash</option>
                            <option value="paypal">Card</option>
                        </select>
                        <h3> No of Seats: </h3>
                        <input type="number"  name="seats" max = '<?php echo($maxseats); ?>' >
                        <br>
                        <input class="btn btn-primary" type="submit" name="joinit" value="Join">
                    </form>
                </div>
    </body>

    </html>


<?php
