<?php
session_start();
require_once("db.php");

$driver = RideshareData::getDBInstance()->get_driver_details($_SESSION['email']);
$DID = $driver[0];




if ($_SERVER['REQUEST_METHOD'] == "POST"){
    $postal_code = $_POST['postal_code'];
    $destination = $_POST['destination'];
    $price = $_POST['price'];
    $address = $_POST['address'];
    $ride_date = $_POST['ride_date']; // format_date_for_sql()
    $ride_time = $_POST['ride_time'];
    date_default_timezone_set('Australia/Melbourne');
    $mySql_ride_time = date('H:i:s',strtotime($ride_time));
    $seats = $_POST['seats'];
    $seatsLeft = $seats;
    $city = $_POST['city'];
    $province = $_POST['province'];

    if ($seats > 0) {

        $insert_success = RideshareData::getDBInstance()->create_ride($DID, $postal_code,
            $destination, $price, $address, $ride_date, $mySql_ride_time, $seats, $seatsLeft, $city, $province);
        if($insert_success[0]) {
            header('Location: home-driver.php');
            exit;
        }
        else{
            echo '<script>alert('.$insert_success[1].');</script>';
        }
    } else {
        echo "Seats must be greater than 0";
    }

}

?>

<!DOCTYPE html>

<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>

    <title>Create a new rideshare</title>
</head>
<body>

<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <nav class="navbar navbar-default" role="navigation">
                <div class="col-md-5">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="home-driver.php".php"><img src="assests/ride.jpg" style="width: 45%; padding: 0px;margin: 0px"></a>
                        </li>
                </div>
                <div class="col-md-5">
                    <ul class="nav navbar-nav">
                        <li><h1>Driver Portal</h1></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <ul class="nav navbar-nav">
                        <li><a href="logout.php"><img src="assests/shutdown.png" style="width: 30%"></a></li>
                    </ul>
                </div>
            </nav>

            <div class = "jumbotron">

                <form role = "form" name="createRideshare" action="create-ride.php" method="POST">
                    <h1>New Ride </h1>

                    <div class = "form-group">
                        <label for = "Destination:">
                            Destination:
                        </label>
                        <input class = "form-control" type="text" name = "destination" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Price:">
                            Price:
                        </label>
                        <input class = "form-control" type="text" name="price" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Address:">
                            Address:
                        </label>
                        <input class = "form-control" type="text" name="address" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Postal Code:">
                            Postal Code:
                        </label>
                        <input class = "form-control" type="text" name="postal_code" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Province:">
                            Province:
                        </label>
                        <input class = "form-control" type="text" name="province" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "City:">
                            City:
                        </label>
                        <input class = "form-control" type="text" name="city" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Departure Date:">
                            Departure Date:
                        </label>
                        <input class = "form-control" type="date" name="ride_date" required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Departure Time: (HH:MM AM/PM)">
                            Departure Time:
                        </label>
                        <input class = "form-control" type="time" name="ride_time"  required/>
                    </div>

                    <div class = "form-group">
                        <label for = "Seats: ">
                            No Of Seats:
                        </label>
                        <input class = "form-control" type="number" name="seats" required/>
                    </div>

                    <input type="submit" value="Create new ride" class = "btn btn-primary"><br>
                </form>
</body>
</html>
