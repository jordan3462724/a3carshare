<?php
session_start();
require_once("db.php");
if (!(array_key_exists("email", $_SESSION) and array_key_exists("type", $_SESSION)))
{
    header('Location: index.php');
    exit;
}

?>

<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
</head>
<body>
<div class="container-fluid">
    <div class="row">
        <div class="col-md-12">
            <nav class="navbar navbar-default" role="navigation">


                <div class="col-md-5">
                    <ul class="nav navbar-nav">
                        <li>
                            <a href="home-passenger.php".php"><img src="assests/ride.jpg" style="width: 45%; padding: 0px;margin: 0px"></a>
                        </li>
                </div>
                <div class="col-md-5">
                    <ul class="nav navbar-nav">
                        <li><h1>Passenger Portal</h1></li>
                    </ul>
                </div>
                <div class="col-md-2">
                    <ul class="nav navbar-nav">
                        <li><a href="logout.php"><img src="assests/shutdown.png" style="width: 30%"></a></li>
                    </ul>
                </div>
            </nav>

            <div class="jumbotron">
                <h2><?php if (array_key_exists("email", $_SESSION)) {
                        echo "Hi, " . $_SESSION['email'];
                    } ?>!</h2>

                <a href="find-rides.php" class="btn btn-info">Check for Ride</a>



            </div>

            <div class="col-md-12">
                <h3>Upcoming Rides: </h3>
                <table class="table table-bordered" border="black">
                    <tr>
                        <th>Date</th>
                        <th>Destination</th>
                        <th>Price</th>
                        <th>Seats Left</th>
                    </tr>
                    <?php
                    $pass = RideshareData::getDBInstance()->passenger_details($_SESSION['email']);
                    $passengerID = $pass[0];
                    $result = RideshareData::getDBInstance()->current_rides($passengerID);
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<tr><td>" . htmlentities($row['ride_date']) . "</td>";
                        echo "<td>" . htmlentities($row['destination']) . "</td>";
                        echo "<td>" . htmlentities($row['price']) . "</td>";
                        echo "<td>" . htmlentities($row['seats_left']) . "</td></tr>\n";

                    }
                    mysqli_free_result($result);
                    ?>
                </table>


                <h3>Past RideShares: </h3>

                <table class="table table-bordered" border="black">
                    <tr>
                        <th>Date</th>
                        <th>Destination</th>
                        <th>Price</th>
                    </tr>
                    <?php
                    $pass = RideshareData::getDBInstance()->passenger_details($_SESSION['email']);
                    $passengerID = $pass[0];
                    $result = RideshareData::getDBInstance()->past_rides($passengerID);
                    while ($row = mysqli_fetch_array($result)) {
                        echo "<tr><td>" . htmlentities($row['ride_date']) . "</td>";
                        echo "<td>" . htmlentities($row['destination']) . "</td>";
                        echo "<td>" . htmlentities($row['price']) . "</td></td></tr>\n";
                    }
                    mysqli_free_result($result);
                    ?>
                </table>
            </div>
        </div>
    </div>
</div>

</body>


</html>
