<?php
session_start();
require_once("db.php");
if (!(array_key_exists("email", $_SESSION) and array_key_exists("type", $_SESSION))) {
    header('Location: index.php');
    exit;
}
?>


    <!DOCTYPE html>
    <head>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    </head>
    <body>


    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <nav class="navbar navbar-default" role="navigation">


                    <div class="col-md-5">
                        <ul class="nav navbar-nav">
                            <li>
                                <a href="home-passenger.php".php"><img src="assests/ride.jpg" style="width: 45%; padding: 0px;margin: 0px"></a>
                            </li>
                    </div>
                    <div class="col-md-5">
                        <ul class="nav navbar-nav">
                            <li><h1>Passenger Portal</h1></li>
                        </ul>
                    </div>
                    <div class="col-md-2">
                        <ul class="nav navbar-nav">
                            <li><a href="logout.php"><img src="assests/shutdown.png" style="width: 30%"></a></li>
                        </ul>
                    </div>
                </nav>

                <div class="jumbotron">
                    <h2><?php if (array_key_exists("email", $_SESSION)) {
                            echo "Hi, " . $_SESSION['email'];
                        } ?>!</h2>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <h3>Search</h3>

                        <div class="form-group">
                            <form role="form"  method="POST">
                                <input type="text" class="form-control" name="destination"
                                       placeholder="Enter your destination ">

                                <button class="btn btn-default" type="submit">Search</button>
                            </form>
                        </div>

                        <div>
                            <h3>Available RideShares</h3>

                            <table class="table table-bordered" border="black">
                                <tr>
                                    <th>Date</th>
                                    <th>Driver Name</th>
                                    <th>Color</th>
                                    <th>Destination</th>
                                    <th>Price</th>
                                    <th>Seats Left</th>
                                    <th>Link</th>
                                </tr>
                                <?php

                                $result = RideshareData::getDBInstance()->get_available_rideshares();
                                while ($row = mysqli_fetch_array($result)) {
                                    $RideID = $row['RID'];
                                    echo "<tr><td>" . htmlentities($row['ride_date']) . "</td>";
                                    echo "<td>" . htmlentities($row['name']) . "</td>";
                                    echo "<td>" . htmlentities($row['color']) . "</td>";
                                    echo "<td>" . htmlentities($row['destination']) . "</td>";
                                    echo "<td>" . htmlentities($row['price']) . "</td>";
                                    echo "<td>" . htmlentities($row['seats_left']) . "</td>";
                                    echo "<td>" . htmlentities("") . "<a href=\"ride-info-passanger.php?RideID=$RideID\">Join</a>" . "</td>";

                                }
                                mysqli_free_result($result);
                                ?>
                            </table>
                        </div>
                    </div>
                    </form>
                </div>
            </div>
        </div>


    </body>
    </html>


<?php
