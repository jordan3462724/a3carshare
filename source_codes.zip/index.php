<?php
require_once("db.php");
$logonSuccess = false;

// verify user's credentials
if ($_SERVER['REQUEST_METHOD'] == "POST") {
    $data = (RideshareData::getDBInstance()->verify_user($_POST['email'], $_POST['password']));
    $logonSuccess = $data[1];
    if ($logonSuccess == true) {
        session_start();
        $_SESSION['email'] = $_POST['email'];
        if ($data[0] == 'passenger') {
            $_SESSION['type'] = 'passenger';
            header('Location: home-passenger.php');
            exit;
        } elseif ($data[0] == 'driver') {
            $_SESSION['type'] = 'driver';
            header('Location: home-driver.php');
            exit;
        }
    }
}

?>

<!DOCTYPE html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.1/js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/angularjs/1.6.9/angular.min.js"></script>

</head>
<body>

<div class="container-fluid" ng-app='myApp'>
    <div ng-controller="rides">
        <div class="row">
            <div class="col-md-12">


                <div class="jumbotron">
                    <h2>
                        Ride sharing
                    </h2>


                    <p>

                        <a href="create-driver.php" class="btn btn-danger">Register As a Driver</a>
                        <a href="create-passenger.php" class="btn btn-primary">Register As a Passenger</a>
                    </p>


                    <form role="form" name="logon" action="index.php" method="POST">
                        <div class="form-group">

                            <label for="email">
                                Username
                            </label>
                            <input type="text" class="form-control" name="email" id="email"/>
                        </div>
                        <div class="form-group">

                            <label for="password">
                                Password
                            </label>
                            <input type="password" class="form-control" name="password" id="password"/>
                        </div>

                        <?php
                        if ($_SERVER['REQUEST_METHOD'] == "POST") {
                            if (!$logonSuccess) {
                                $_SERVER['REQUEST_METHOD'] == '';
                                echo '<script>alert("Invalid Credentials")</script>';
                            }

                        }
                        ?>

                        <button type="submit" value="Login" class="btn btn-warning">
                            Login
                        </button>
                    </form>

                </div>

            </div>

        </div>
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-9">
                <button class="btn btn-success" value="check for rides" ng-click="get_rides()">check for rides</button>
                <h6>To join please login to the system</h6>
            </div>
        </div>
        <div class="row" ng-if="viewrides">
            <div class="col-md-1"></div>
            <div class="col-md-10">
                <table class="table table-bordered">
                    <tr>
                        <th>Destination</th>
                        <th>Driver Name</th>
                        <th>No of seats left</th>
                    </tr>
                    <tr ng-repeat="rd in rides_data">
                        <td>{{rd.destination}}</td>
                        <td>{{rd.drivername}}</td>
                        <td>{{rd['seats left']}}</td>
                    </tr>
                </table>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>

</div>


</body>
</html>
<script>
    var app = angular.module('myApp', []);

    app.controller('rides',  function($scope,$http)
    {
        $scope.viewrides = false;
        $scope.get_rides = function () {
            console.log("getting data ...");
            $http({
                method : "GET",
                url : "https://7tuivugno9.execute-api.us-east-1.amazonaws.com/rides/"
            }).then(function mySuccess(response) {
                r = response.data.body;
                // angular.forEach(r, function (value, key) {
                //     $scope.rides_data.push(value);
                // });
                const obj = JSON.parse(r);
                $scope.rides_data = obj;
                $scope.viewrides = true;
                console.log($scope.rides_data);
            }, function myError(response) {
                console.log(response);
            });
        };

    });
</script>