<?php
class RideshareData extends mysqli
{
    private static $connection = null;

    private $servername = "aa10g3a2c8wkegu.c4emz9m6sieb.us-east-1.rds.amazonaws.com";
    private $username = "root";
    private $password = "Assignment3";
    private $dbname = "rideshare";


    // private constructor
    public function __construct()
    {
        parent::__construct($this->servername, $this->username, $this->password, $this->dbname);
        if (mysqli_connect_error()) {
            exit('Connect Error (' . mysqli_connect_errno() . ') '
                . mysqli_connect_error());
        }
        parent::set_charset('utf-8');
    }

    public static function getDBInstance()
    {
        if (!self::$connection instanceof self) {
            self::$connection = new self;
        }
        return self::$connection;
    }


    public function verify_user($email, $password)
    {
        $type = '';
        $email = $this->real_escape_string($email);
        $password = $this->real_escape_string($password);

        $result = $this->query("SELECT 1 FROM drivers WHERE email = '".$email."' AND password = '".$password."'");

        if ($result->data_seek(0) == TRUE) {
            $type = 'driver';
            return array($type , $result->data_seek(0));
        }
        else
        {
            $result = $this->query("SELECT 1 FROM passengers WHERE email = '".$email."' AND password = '".$password."'");
            $type = 'passenger';
            return array($type, $result->data_seek(0));
        }

    }

    public function get_available_rideshares(){
        return $this->query("SELECT ride_date, name, destination, price, seats, seats_left, RID, color
                  FROM rides R, drivers D, car C
                  WHERE R.DID = D.DID AND seats_left > 0 AND R.ride_date >= current_date AND D.licenseNum = C.licenseNum");
    }

    public function get_driver_details($email) {
        $email = $this->real_escape_string($email);
        $driver = $this->query("SELECT * FROM drivers WHERE email = '".$email."'");

        if ($driver->num_rows > 0){
            return $driver->fetch_row();
        } else
            return null;
    }

    public function create_ride($DID, $postal_code,
                                     $destination, $price, $address,
                                     $ride_date, $ride_time, $seats, $seats_left, $city, $province){

        $DID = $this->real_escape_string($DID);
        $postal_code = $this->real_escape_string($postal_code);
        $destination = $this->real_escape_string($destination);
        $price = $this->real_escape_string($price);
        $address = $this->real_escape_string($address);
        $ride_date = $this->real_escape_string($ride_date);
        $ride_time = $this->real_escape_string($ride_time);
        $seats = $this->real_escape_string($seats);
        $seats_left = $this->real_escape_string($seats_left);
        $city = $this->real_escape_string($city);
        $province = $this->real_escape_string($province);

        $this->query("INSERT INTO locations (postal_code, city, province) VALUES ('$postal_code', '$city','$province')
        ON DUPLICATE KEY UPDATE postal_code = '$postal_code'");

        $this->query("INSERT INTO rides (DID,  postal_code, destination, address, price, ride_date, ride_time, seats, seats_left, createddatetime)
                      VALUES ( '$DID',
                                 '$postal_code', '$destination',
                                 '$address','$price',
                                 '$ride_date','$ride_time',
                                 '$seats','$seats_left', NOW())");
        if($this->error)
        {
            return array(FALSE,$this->error) ;
        }
        else
        {
            return array(TRUE);
        }

    }

    public function get_current_ride_shares_by_id($driver_id){
        return $this->query("SELECT ride_date, destination, price, seats, seats_left, RID
                  FROM rides R, drivers D
                  WHERE $driver_id = D.DID AND R.DID = D.DID AND R.ride_date >= current_date()");
    }

    public function get_ride_info($RID){
        return $this->query("SELECT ride_date, name, destination, price, seats, seats_left, RID, address, ride_time
                  FROM rides R, drivers D
                  WHERE R.RID = $RID AND R.DID = D.DID AND seats_left > 0 AND R.ride_date >= current_date()");
    }

    public function update_ride($Destination, $RID){

        $this->query("UPDATE rides
                      SET destination= '". $Destination ."'
                      WHERE RID=" . $RID);
    }

    public function get_past_drivers_rides($driverID){
        return $this->query("SELECT ride_date, destination, price, seats, seats_left, RID
                  FROM rides R, drivers D
                  WHERE $driverID = D.DID AND R.DID = D.DID AND R.ride_date < current_date()");
    }

    public function ride_transactions_details($rideShareID){
        return $this->query("SELECT p.name, pa.Type, R.price
                FROM participates pa, passengers p, rides R
                Where pa.PID = p.PID AND R.RID = $rideShareID AND pa.RID = $rideShareID");
    }

    public function passenger_details($email) {
        $email = $this->real_escape_string($email);
        $passenger = $this->query("SELECT * FROM passengers WHERE email = '".$email."'");

        if ($passenger->num_rows > 0){
            $row = $passenger->fetch_row();
            return $row;
        } else
            return null;
    }

    public function participates($PID, $RID){
        $participates = $this->query("SELECT * FROM participates P WHERE P.RID = '".$RID."' AND P.PID = '".$PID."' ");
        return $participates->num_rows;
    }

    public function rides($RID){
        return $this->query("SELECT ride_date, name, destination, price, seats, seats_left, RID, address, ride_time
                  FROM rides R, drivers D
                  WHERE R.RID = $RID AND R.DID = D.DID AND seats_left > 0 AND R.ride_date >= current_date ");
    }

    public function join_ride($PID, $RID, $Type, $seats){

        $PID = $this->real_escape_string($PID);
        $RID = $this->real_escape_string($RID);
        $Type = $this->real_escape_string($Type);
        $seats = $this->real_escape_string($seats);


        $this->query("UPDATE rides SET seats_left = seats_left - ".$seats." WHERE RID = '$RID' AND seats_left > 0");
        if($this->affected_rows > 0) {
            $this->query("INSERT INTO participates (PID, RID, Type) VALUES ('".$PID."', '".$RID."', '".$Type."')");
            return "joining success";
        }
        else
        {
            return "no seats";
        }

    }

    public function current_rides($passengerID){
        return $this->query("SELECT ride_date, destination, price, seats_left
                  FROM rides R, passengers P, participates Pa
                  WHERE $passengerID = P.PID AND P.PID = Pa.PID AND R.RID = Pa.RID AND R.ride_date >= current_date ");
    }

    public function past_rides($passengerID){
        return $this->query("SELECT ride_date, destination, price
                  FROM rides R, passengers P, participates Pa
                  WHERE $passengerID = P.PID AND P.PID = Pa.PID AND R.RID = Pa.RID AND R.ride_date < current_date ");
    }

    public function create_driver($name, $email, $phoneNum, $password, $licenseNum, $type, $color) {
        $name = $this->real_escape_string($name);
        $email = $this->real_escape_string($email);
        $phoneNum = $this->real_escape_string($phoneNum);
        $licenseNum = $this->real_escape_string($licenseNum);
        $password = $this->real_escape_string($password);
        $type = $this->real_escape_string($type);
        $color = $this->real_escape_string($color);

        $this->query("INSERT INTO Car (licenseNum, type, color)" .
            " VALUES ('" . $licenseNum . "',
             '" . $type. "',
              '" .$color."'
            )");

        $this->query("INSERT INTO drivers (name, email, phoneNum, licenseNum, password)" .
            "VALUES ('" . $name . "',
         '" . $email . "',
         '" . $phoneNum . "',
         '" . $licenseNum . "',
         '" . $password . "'
         )");
    }

    public function create_passenger($name, $email, $phoneNum, $password){
        $name = $this->real_escape_string($name);
        $email = $this->real_escape_string($email);
        $phoneNum = $this->real_escape_string($phoneNum);
        $password = $this->real_escape_string($password);

        $this->query("INSERT INTO passengers (name, email, phoneNum, password)" .
            "VALUES ('" . $name . "',
         '" . $email . "',
         '" . $phoneNum . "',
         '" . $password . "'
         )");


    }

}
?>
